#!/bin/bash
/bin/nfoextract.sh $@
/bin/nfoextract2.sh $@
exit 0
